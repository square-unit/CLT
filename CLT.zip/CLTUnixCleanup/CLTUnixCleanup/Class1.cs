﻿using System;
using System.Drawing;

namespace CLTUnixCleanup
{
    public class Class1
    {

    }


}