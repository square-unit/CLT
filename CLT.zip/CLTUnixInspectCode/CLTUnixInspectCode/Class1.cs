﻿using System;
using CLTUnixInspectCode.ExcludeMe;

namespace CLTUnixInspectCode
{
    public class Class1
    {
        public void Foo(out bool y, bool x)
        {
            var c = new Class2();
            Console.WriteLine(c.NeverAssignedField);

            if (y = x)
            {
            }
        }
    }
}