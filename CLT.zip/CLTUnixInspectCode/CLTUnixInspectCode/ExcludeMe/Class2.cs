﻿namespace CLTUnixInspectCode.ExcludeMe
{
    public class Class2
    {
        public string NeverAssignedField;
    }
}